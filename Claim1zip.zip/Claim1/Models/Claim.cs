﻿
namespace Claim1.Models
{
    public class Claim
    {
        public int ClaimId { get; set; }
        public double Amount { get; set; }
        public string Status { get; set; } // "Pending", "Approved", "Rejected"
        public string Role { get; set; } // "Worker", "Manager", "CEO"
        public string SupportingDocuments { get; set; } // Path or URL to document
        public int HoursWorked { get; set; }
        public string Module { get; set; }
        public DateTime ClaimDate { get; set; }
        public string Comments { get; set; }
    }
}
