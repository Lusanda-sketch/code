
using Claim1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using Microsoft.AspNetCore.Http;

namespace Claim1.Controllers
{
    public class HomeController : Controller
    {
        private static List<Claim> claims = new List<Claim>();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Lecturers()
        {
            var lecturerClaims = claims.Where(c => c.Role == "Lecturer").ToList();
            return View(lecturerClaims);
        }

        public ActionResult ProgramCoordinator()
        {
            var coordinatorClaims = claims.Where(c => c.Status == "Pending" || c.Status == "Approved by Coordinator" || c.Status == "Rejected by Coordinator").ToList();
            return View(coordinatorClaims);
        }

        public ActionResult Academic()
        {
            var managerClaims = claims.Where(c => c.Status == "Approved by Coordinator" || c.Status == "Verified by Manager" || c.Status == "Rejected by Manager").ToList();
            return View(managerClaims);
        }

        public ActionResult UnverifiedClaims()
        {
            var unverifiedClaims = claims.Where(c => c.Status == "Approved by Coordinator").ToList();
            return View(unverifiedClaims);
        }

        [HttpPost]
        public ActionResult CreateClaim(Claim claim, IFormFile document)
        {
            if (document != null && document.Length > 0)
            {
                string uploadsFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/Documents");
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + document.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);




            }

            claim.ClaimId = claims.Count + 1;
            claim.Status = "Pending";
            claim.Role = "Lecturer";
          
            claims.Add(claim);
            return RedirectToAction("Lecturers");
        }

        [HttpPost]
        public ActionResult UpdateStatus(int id, string status)
        {
            var claim = claims.FirstOrDefault(c => c.ClaimId == id);
            if (claim != null)
            {
                claim.Status = status;
            }

            if (status == "Approved by Coordinator" || status == "Rejected by Coordinator")
            {
                return RedirectToAction("ProgramCoordinator");
            }
            else if (status == "Verified by Manager" || status == "Rejected by Manager")
            {
                return RedirectToAction("Lecturer");
            }
            else
            {
                return RedirectToAction("Index");
            }
        }

        public IActionResult ViewDocument(string path)
        {
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot" + path);
            var mimeType = "application/octet-stream";
            return PhysicalFile(filePath, mimeType);
        }
    }
}